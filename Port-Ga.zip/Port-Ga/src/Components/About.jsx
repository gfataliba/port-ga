import React, { Component } from 'react'

class About extends Component {
    render() {
        return (
            <section id="container-about" className="container-about">
                    <h1>Sobre mim</h1> 

                    <p>
                    Me chamo Gabriel, tenho 24 anos sou desenvolvedor focado em criar 
                    soluções web eficientes e funcionais. Com experiência em React, Pyton, JavaScript
                     e Node.js, busco sempre aprender e evoluir com cada projeto.
                    </p>
                
            </section>
        )
    }
}

export default About
