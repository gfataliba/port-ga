import React, { Component } from 'react'




class Portfolio extends Component {
    render() {
        return (
            
            <section className="projects">
                  <h1 id='Portfolio'>Portfolio</h1>
                  <p>Ainda não tenho um projeto relevante.</p>

                       
            </section>
        )
    }
}

export default Portfolio


