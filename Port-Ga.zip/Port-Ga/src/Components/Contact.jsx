import React, { Component } from 'react'
import contact from '../Components/public/image/contactlogo.png';
import mailme from '../Components/public/image/mailmeimg.png';


class Contact extends Component {
    render() {
        return (
            <section className="container-1">

                <img id="contactimg" src={contact} width="180" height="180" alt="contactlogo"/>
                <h4>gabriel_ataliba@hotmail.com</h4>
                <a id="mail"href="https://mail.google.com/mail/?view=cm&fs=1&to=gabriel_ataliba@hotmail.com"><img id="mailmelogo" src={mailme} alt="mail me"/>Clique aqui para me enviar um e-mail</a>
                        <a href="https://github.com/gfataliba">
                                <span className="icon fa fa-github" style={{color:'antiquewhite'}} ></span>
                        </a>          
            </section>
        )
    }
}

export default Contact
