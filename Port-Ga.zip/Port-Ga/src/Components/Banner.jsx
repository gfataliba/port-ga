import React, { Component } from 'react'
import logo from '../Components/public/image/maxresdefault.jpg';



class Banner extends Component {
    render() {
        return (
            <section className="container-banner">

                    <a href="#home"><img id="profilepic" src={logo}  width="170" height="170" alt="profilepic"/></a>
                    <h1> Olá, sou Gabriel</h1>
                    <p id="paragarph1"> Front-end <br/>
                    Developer</p>
                    <br />
                    
            </section>
        )
    }
}

export default Banner


